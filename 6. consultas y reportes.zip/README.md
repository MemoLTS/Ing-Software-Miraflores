
  # 6. consultas y reportes

  This is a code bundle for 6. consultas y reportes. The original project is available at https://www.figma.com/design/DMKzsq9630qRLdY3au5SGp/6.-consultas-y-reportes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  