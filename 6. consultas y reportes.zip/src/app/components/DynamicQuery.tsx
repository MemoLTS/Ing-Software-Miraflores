import { useState } from "react";
import { Play, Plus, Trash2, ChevronDown, BarChart2, TableIcon, FileText, Download, RefreshCw, CheckCircle2, Clock, XCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";

// ─── Datos base ───────────────────────────────────────────────────────────────
type Residente = {
  id: string;
  nombre: string;
  apartamento: string;
  piso: number;
  tipo: "Propietario" | "Arrendatario";
  estado: "Al día" | "Con mora" | "Deuda crítica";
  deuda: number;
  mesesMora: number;
  ultimoPago: string;
};

const BASE: Residente[] = [
  { id: "R001", nombre: "Ana García Fuentes",     apartamento: "101", piso: 1, tipo: "Propietario",  estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-05-28" },
  { id: "R002", nombre: "Carlos Muñoz Pinto",      apartamento: "203", piso: 2, tipo: "Arrendatario", estado: "Con mora",     deuda: 120000, mesesMora: 1, ultimoPago: "2026-04-30" },
  { id: "R003", nombre: "Lucía Vera Soto",         apartamento: "305", piso: 3, tipo: "Propietario",  estado: "Deuda crítica",deuda: 360000, mesesMora: 3, ultimoPago: "2026-02-28" },
  { id: "R004", nombre: "Tomás Ríos Lagos",        apartamento: "401", piso: 4, tipo: "Arrendatario", estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-05-30" },
  { id: "R005", nombre: "Valentina Bravo Núñez",   apartamento: "502", piso: 5, tipo: "Propietario",  estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-06-01" },
  { id: "R006", nombre: "Roberto Cruz Valdivia",   apartamento: "504", piso: 5, tipo: "Arrendatario", estado: "Con mora",     deuda: 240000, mesesMora: 2, ultimoPago: "2026-03-31" },
  { id: "R007", nombre: "Fernanda López Cruz",     apartamento: "601", piso: 6, tipo: "Propietario",  estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-06-01" },
  { id: "R008", nombre: "Rodrigo Sánchez Vega",    apartamento: "712", piso: 7, tipo: "Arrendatario", estado: "Con mora",     deuda: 240000, mesesMora: 2, ultimoPago: "2026-03-28" },
  { id: "R009", nombre: "Camila Torres Núñez",     apartamento: "803", piso: 8, tipo: "Propietario",  estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-05-29" },
  { id: "R010", nombre: "Diego Morales Espinoza",  apartamento: "901", piso: 9, tipo: "Arrendatario", estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-05-31" },
  { id: "R011", nombre: "Patricia Herrera Vidal",  apartamento: "102", piso: 1, tipo: "Propietario",  estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-06-02" },
  { id: "R012", nombre: "Marco Castillo Reyes",    apartamento: "204", piso: 2, tipo: "Propietario",  estado: "Con mora",     deuda: 120000, mesesMora: 1, ultimoPago: "2026-04-29" },
  { id: "R013", nombre: "Sofía Rueda Morales",     apartamento: "306", piso: 3, tipo: "Arrendatario", estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-05-30" },
  { id: "R014", nombre: "Felipe Aguirre Salas",    apartamento: "403", piso: 4, tipo: "Propietario",  estado: "Deuda crítica",deuda: 480000, mesesMora: 4, ultimoPago: "2026-01-31" },
  { id: "R015", nombre: "Isidora Peña Contreras",  apartamento: "505", piso: 5, tipo: "Arrendatario", estado: "Al día",       deuda: 0,      mesesMora: 0, ultimoPago: "2026-06-01" },
];

// ─── Tipos ────────────────────────────────────────────────────────────────────
type Criterio = { id: number; campo: string; operador: string; valor: string };

const CAMPOS = ["Tipo de residente", "Estado de cuenta", "Piso", "Meses de mora", "Deuda total"];
const OPERADORES: Record<string, string[]> = {
  "Tipo de residente": ["es igual a"],
  "Estado de cuenta":  ["es igual a"],
  "Piso":              ["es igual a", "mayor que", "menor que"],
  "Meses de mora":     ["es igual a", "mayor o igual a", "mayor que", "igual a 0"],
  "Deuda total":       ["mayor que", "igual a 0", "mayor o igual a"],
};
const VALORES: Record<string, string[]> = {
  "Tipo de residente": ["Propietario", "Arrendatario"],
  "Estado de cuenta":  ["Al día", "Con mora", "Deuda crítica"],
  "Piso":              ["1","2","3","4","5","6","7","8","9"],
};

const CONSULTAS_GUARDADAS = [
  { nombre: "Residentes en mora (≥1 mes)", criterios: [{ id: 1, campo: "Meses de mora", operador: "mayor o igual a", valor: "1" }] },
  { nombre: "Deudas críticas", criterios: [{ id: 1, campo: "Estado de cuenta", operador: "es igual a", valor: "Deuda crítica" }] },
  { nombre: "Arrendatarios al día", criterios: [{ id: 1, campo: "Tipo de residente", operador: "es igual a", valor: "Arrendatario" }, { id: 2, campo: "Estado de cuenta", operador: "es igual a", valor: "Al día" }] },
  { nombre: "Propietarios con mora", criterios: [{ id: 1, campo: "Tipo de residente", operador: "es igual a", valor: "Propietario" }, { id: 2, campo: "Meses de mora", operador: "mayor o igual a", valor: "1" }] },
];

// ─── Motor de filtrado ─────────────────────────────────────────────────────────
function aplicarCriterios(datos: Residente[], criterios: Criterio[]): Residente[] {
  return datos.filter(r =>
    criterios.every(c => {
      const v = c.valor;
      switch (c.campo) {
        case "Tipo de residente": return r.tipo === v;
        case "Estado de cuenta":  return r.estado === v;
        case "Piso": {
          const n = Number(v);
          if (c.operador === "mayor que") return r.piso > n;
          if (c.operador === "menor que") return r.piso < n;
          return r.piso === n;
        }
        case "Meses de mora": {
          if (c.operador === "igual a 0") return r.mesesMora === 0;
          const n = Number(v);
          if (c.operador === "mayor o igual a") return r.mesesMora >= n;
          if (c.operador === "mayor que") return r.mesesMora > n;
          return r.mesesMora === n;
        }
        case "Deuda total": {
          if (c.operador === "igual a 0") return r.deuda === 0;
          const n = Number(v);
          if (c.operador === "mayor o igual a") return r.deuda >= n;
          if (c.operador === "mayor que") return r.deuda > n;
          return r.deuda === n;
        }
        default: return true;
      }
    })
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmtCLP  = (n: number) => n === 0 ? "$0" : new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(n);
const fmtDate = (s: string) => new Date(s).toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" });
const now     = () => new Date().toLocaleString("es-CL", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

const estadoColor = (e: string) => {
  if (e === "Al día") return "text-green-700 bg-green-50";
  if (e === "Con mora") return "text-amber-700 bg-amber-50";
  return "text-red-700 bg-red-50";
};
const EstadoBadge = ({ e }: { e: string }) => (
  <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium w-fit ${estadoColor(e)}`}>
    {e === "Al día" ? <CheckCircle2 size={10}/> : e === "Con mora" ? <Clock size={10}/> : <XCircle size={10}/>}
    {e}
  </span>
);

const PIE_COLORS = ["#1B2E4B", "#2563EB", "#DC2626", "#10B981"];

// ─── Componente principal ─────────────────────────────────────────────────────
export function DynamicQuery() {
  const [criterios, setCriterios] = useState<Criterio[]>([
    { id: 1, campo: "Meses de mora", operador: "mayor o igual a", valor: "1" },
  ]);
  const [resultado, setResultado] = useState<Residente[] | null>(null);
  const [generandoEn, setGenerandoEn] = useState<string | null>(null);
  const [vista, setVista] = useState<"tabla" | "grafico">("tabla");
  const [loading, setLoading] = useState(false);

  const nextId = Math.max(0, ...criterios.map(c => c.id)) + 1;

  const addCriterio = () =>
    setCriterios(c => [...c, { id: nextId, campo: "Estado de cuenta", operador: "es igual a", valor: "Con mora" }]);
  const removeCriterio = (id: number) =>
    setCriterios(c => c.filter(x => x.id !== id));
  const updateCriterio = (id: number, field: keyof Criterio, value: string) =>
    setCriterios(c => c.map(x =>
      x.id === id
        ? { ...x, [field]: value, ...(field === "campo" ? { operador: (OPERADORES[value] || ["es igual a"])[0], valor: "" } : {}) }
        : x
    ));

  const ejecutar = (criters = criterios) => {
    setLoading(true);
    setTimeout(() => {
      setResultado(aplicarCriterios(BASE, criters));
      setGenerandoEn(now());
      setLoading(false);
    }, 600);
  };

  const cargarConsulta = (q: typeof CONSULTAS_GUARDADAS[0]) => {
    setCriterios(q.criterios.map(c => ({ ...c })));
    ejecutar(q.criterios);
  };

  // Agrupaciones para gráficos
  const porEstado = resultado
    ? [
        { name: "Al día",       value: resultado.filter(r => r.estado === "Al día").length },
        { name: "Con mora",     value: resultado.filter(r => r.estado === "Con mora").length },
        { name: "Deuda crítica",value: resultado.filter(r => r.estado === "Deuda crítica").length },
      ].filter(g => g.value > 0)
    : [];

  const porTipo = resultado
    ? [
        { name: "Propietario",  value: resultado.filter(r => r.tipo === "Propietario").length },
        { name: "Arrendatario", value: resultado.filter(r => r.tipo === "Arrendatario").length },
      ].filter(g => g.value > 0)
    : [];

  const porPiso = resultado
    ? Array.from(new Set(resultado.map(r => r.piso))).sort((a, b) => a - b).map(p => ({
        piso: `P${p}`,
        residentes: resultado.filter(r => r.piso === p).length,
        deuda: resultado.filter(r => r.piso === p).reduce((s, r) => s + r.deuda, 0),
      }))
    : [];

  const totalDeuda = resultado ? resultado.reduce((s, r) => s + r.deuda, 0) : 0;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      {/* Encabezado */}
      <div>
        <h1 className="text-foreground">Consultas e Informes Dinámicos</h1>
        <p className="text-sm text-muted-foreground mt-0.5">RF-19 — Configure criterios y genere el informe al ejecutar</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* ── Panel izquierdo ── */}
        <div className="space-y-4">
          {/* Constructor */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-foreground mb-4">Constructor de Criterios</h3>

            <div className="space-y-3">
              {criterios.map((c, i) => (
                <div key={c.id} className="space-y-2">
                  {i > 0 && (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-px bg-border" />
                      <span className="text-xs font-semibold text-accent px-2">Y además</span>
                      <div className="flex-1 h-px bg-border" />
                    </div>
                  )}
                  <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                    {/* Campo */}
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Campo</label>
                      <div className="relative">
                        <select
                          value={c.campo}
                          onChange={e => updateCriterio(c.id, "campo", e.target.value)}
                          className="w-full appearance-none bg-card border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent pr-7"
                        >
                          {CAMPOS.map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                        <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                      </div>
                    </div>
                    {/* Operador */}
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Condición</label>
                      <div className="relative">
                        <select
                          value={c.operador}
                          onChange={e => updateCriterio(c.id, "operador", e.target.value)}
                          className="w-full appearance-none bg-card border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent pr-7"
                        >
                          {(OPERADORES[c.campo] || ["es igual a"]).map(op => <option key={op}>{op}</option>)}
                        </select>
                        <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                      </div>
                    </div>
                    {/* Valor (oculto si operador no lo necesita) */}
                    {!["igual a 0"].includes(c.operador) && (
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">Valor</label>
                        {VALORES[c.campo] ? (
                          <div className="relative">
                            <select
                              value={c.valor}
                              onChange={e => updateCriterio(c.id, "valor", e.target.value)}
                              className="w-full appearance-none bg-card border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent pr-7"
                            >
                              <option value="">Seleccionar...</option>
                              {VALORES[c.campo].map(v => <option key={v}>{v}</option>)}
                            </select>
                            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                          </div>
                        ) : (
                          <input
                            type="number"
                            value={c.valor}
                            onChange={e => updateCriterio(c.id, "valor", e.target.value)}
                            placeholder="Número..."
                            className="w-full bg-card border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent"
                          />
                        )}
                      </div>
                    )}
                    {/* Quitar criterio */}
                    {criterios.length > 1 && (
                      <button onClick={() => removeCriterio(c.id)} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors mt-1">
                        <Trash2 size={11} /> Eliminar criterio
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <button onClick={addCriterio} className="flex items-center gap-1.5 text-sm text-accent hover:text-accent/80 transition-colors mt-4">
              <Plus size={14} /> Añadir criterio
            </button>

            <button
              onClick={() => ejecutar(criterios)}
              disabled={loading}
              className="w-full mt-4 flex items-center justify-center gap-2 bg-accent text-accent-foreground py-2.5 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-60"
            >
              {loading ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
              {loading ? "Generando informe..." : "Generar Informe"}
            </button>
          </div>

          {/* Consultas guardadas */}
          <div className="bg-card border border-border rounded-xl p-4">
            <h3 className="text-foreground mb-3">Consultas Guardadas</h3>
            <div className="space-y-1.5">
              {CONSULTAS_GUARDADAS.map((q) => (
                <button
                  key={q.nombre}
                  onClick={() => cargarConsulta(q)}
                  className="w-full text-left p-2.5 bg-muted/40 hover:bg-muted rounded-lg transition-colors group"
                >
                  <p className="text-sm font-medium text-foreground group-hover:text-accent transition-colors">{q.nombre}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{q.criterios.length} criterio{q.criterios.length > 1 ? "s" : ""}</p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ── Panel derecho: Informe ── */}
        <div className="xl:col-span-2">
          {!resultado && !loading && (
            <div className="h-full min-h-[400px] bg-card border border-dashed border-border rounded-xl flex flex-col items-center justify-center text-center p-10">
              <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center mb-4">
                <FileText size={24} className="text-muted-foreground" />
              </div>
              <p className="font-medium text-foreground">Sin informe generado</p>
              <p className="text-sm text-muted-foreground mt-1.5 max-w-xs">
                Configure los criterios de búsqueda o seleccione una consulta guardada y haga clic en <strong>Generar Informe</strong>.
              </p>
            </div>
          )}

          {loading && (
            <div className="h-full min-h-[400px] bg-card border border-border rounded-xl flex flex-col items-center justify-center gap-3">
              <RefreshCw size={28} className="text-accent animate-spin" />
              <p className="text-sm text-muted-foreground">Procesando consulta...</p>
            </div>
          )}

          {resultado && !loading && (
            <div className="space-y-4">
              {/* Cabecera del informe */}
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <FileText size={15} className="text-accent" />
                      <span className="text-xs text-accent font-semibold uppercase tracking-wider">Informe generado</span>
                    </div>
                    <h2 className="text-foreground">Resultados de Consulta</h2>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Edificio Las Torres · {generandoEn}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {criterios.map((c, i) => (
                        <span key={c.id} className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">
                          {i > 0 && "y "}{c.campo} {c.operador}{c.valor ? ` "${c.valor}"` : ""}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => ejecutar(criterios)}
                      className="flex items-center gap-1.5 text-xs border border-border text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg transition-colors"
                    >
                      <RefreshCw size={12} /> Actualizar
                    </button>
                    <button className="flex items-center gap-1.5 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors">
                      <Download size={12} /> Exportar
                    </button>
                  </div>
                </div>

                {/* KPIs del informe */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
                  {[
                    { label: "Residentes",    value: resultado.length.toString(),  sub: "encontrados" },
                    { label: "Deuda total",   value: fmtCLP(totalDeuda),           sub: "acumulada" },
                    { label: "Promedio mora", value: resultado.length > 0 ? `${(resultado.reduce((s,r)=>s+r.mesesMora,0)/resultado.length).toFixed(1)} m` : "—", sub: "por residente" },
                    { label: "Sin deuda",     value: resultado.filter(r=>r.deuda===0).length.toString(), sub: `de ${resultado.length}` },
                  ].map(k => (
                    <div key={k.label} className="bg-muted/50 rounded-lg p-3 text-center">
                      <p className="text-xl font-semibold text-foreground">{k.value}</p>
                      <p className="text-xs font-medium text-foreground mt-0.5">{k.label}</p>
                      <p className="text-xs text-muted-foreground">{k.sub}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Vista tabla / gráfico */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
                  <p className="text-sm font-medium text-foreground">{resultado.length} registro{resultado.length !== 1 ? "s" : ""}</p>
                  <div className="flex gap-1 bg-muted rounded-lg p-1">
                    <button onClick={() => setVista("tabla")} className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition-all ${vista === "tabla" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground"}`}>
                      <TableIcon size={11} /> Tabla
                    </button>
                    <button onClick={() => setVista("grafico")} className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition-all ${vista === "grafico" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground"}`}>
                      <BarChart2 size={11} /> Gráficos
                    </button>
                  </div>
                </div>

                {vista === "tabla" ? (
                  resultado.length === 0 ? (
                    <div className="py-16 text-center">
                      <p className="text-muted-foreground text-sm">Ningún residente cumple los criterios definidos.</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-muted/40">
                            {["Residente", "Apto.", "Tipo", "Estado", "Meses mora", "Deuda", "Último pago"].map(h => (
                              <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {resultado.map((r, i) => (
                            <tr key={r.id} className={`border-t border-border hover:bg-muted/20 transition-colors ${i%2===0?"":"bg-muted/10"}`}>
                              <td className="px-4 py-3 font-medium text-foreground whitespace-nowrap">{r.nombre}</td>
                              <td className="px-4 py-3 text-muted-foreground">{r.apartamento}</td>
                              <td className="px-4 py-3">
                                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${r.tipo==="Propietario"?"bg-primary/10 text-primary":"bg-accent/10 text-accent"}`}>{r.tipo}</span>
                              </td>
                              <td className="px-4 py-3"><EstadoBadge e={r.estado} /></td>
                              <td className="px-4 py-3 text-center">
                                {r.mesesMora > 0
                                  ? <span className="font-mono text-xs font-semibold text-red-600">{r.mesesMora}</span>
                                  : <span className="text-muted-foreground">—</span>}
                              </td>
                              <td className="px-4 py-3 font-medium text-foreground">{fmtCLP(r.deuda)}</td>
                              <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{fmtDate(r.ultimoPago)}</td>
                            </tr>
                          ))}
                        </tbody>
                        {totalDeuda > 0 && (
                          <tfoot>
                            <tr className="border-t-2 border-border bg-muted/30">
                              <td colSpan={5} className="px-4 py-3 text-sm font-semibold text-foreground">Total</td>
                              <td className="px-4 py-3 font-semibold text-foreground">{fmtCLP(totalDeuda)}</td>
                              <td />
                            </tr>
                          </tfoot>
                        )}
                      </table>
                    </div>
                  )
                ) : (
                  <div className="p-5 space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {porEstado.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Por Estado de Cuenta</p>
                          <ResponsiveContainer width="100%" height={180}>
                            <PieChart>
                              <Pie data={porEstado} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={3} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                                {porEstado.map((entry, i) => <Cell key={`estado-${entry.name}`} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                              </Pie>
                              <Tooltip />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                      {porTipo.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Por Tipo de Residente</p>
                          <ResponsiveContainer width="100%" height={180}>
                            <PieChart>
                              <Pie data={porTipo} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={3} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                                {porTipo.map((entry, i) => <Cell key={`tipo-${entry.name}`} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                              </Pie>
                              <Tooltip />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      )}
                    </div>
                    {porPiso.length > 1 && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Distribución por Piso</p>
                        <ResponsiveContainer width="100%" height={180}>
                          <BarChart data={porPiso} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,46,75,0.06)" />
                            <XAxis dataKey="piso" tick={{ fontSize: 11, fill: "#6B7A8F" }} axisLine={false} tickLine={false} />
                            <YAxis tick={{ fontSize: 10, fill: "#6B7A8F" }} axisLine={false} tickLine={false} allowDecimals={false} />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar dataKey="residentes" name="Residentes" fill="#2563EB" radius={[4,4,0,0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
