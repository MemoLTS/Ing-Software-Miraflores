import { useState } from "react";
import { Building2, Eye, EyeOff, LogIn, AlertCircle } from "lucide-react";
import type { Role } from "./Sidebar";

const USUARIOS: Record<string, { password: string; role: Role; nombre: string; sub: string }> = {
  "admin@lastorres.cl":        { password: "admin123",   role: "admin",        nombre: "Ana Martínez",           sub: "Administradora" },
  "propietario@lastorres.cl":  { password: "prop123",    role: "propietario",  nombre: "Patricia Herrera Vidal", sub: "Propietaria · Apto. 504" },
  "arrendatario@lastorres.cl": { password: "arrend123",  role: "arrendatario", nombre: "Roberto Cruz Valdivia",  sub: "Arrendatario · Apto. 504" },
};

interface Props {
  onLogin: (role: Role) => void;
}

export function Login({ onLogin }: Props) {
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error,    setError]    = useState("");
  const [loading,  setLoading]  = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    setTimeout(() => {
      const user = USUARIOS[email.toLowerCase().trim()];
      if (user && user.password === password) {
        onLogin(user.role);
      } else {
        setError("Correo o contraseña incorrectos.");
      }
      setLoading(false);
    }, 700);
  };

  const quickLogin = (email: string) => {
    const user = USUARIOS[email];
    if (user) {
      setEmail(email);
      setPassword(user.password);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center mb-4 shadow-lg">
            <Building2 size={28} className="text-white" />
          </div>
          <h1 className="text-foreground text-center">GestiónHogar</h1>
          <p className="text-sm text-muted-foreground mt-1">Edificio Las Torres — Acceso al sistema</p>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl p-8 shadow-sm">
          <h2 className="text-foreground mb-1">Iniciar sesión</h2>
          <p className="text-sm text-muted-foreground mb-6">Ingrese sus credenciales para continuar</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="text-xs font-medium text-foreground mb-1.5 block">Correo electrónico</label>
              <input
                type="email"
                value={email}
                onChange={e => { setEmail(e.target.value); setError(""); }}
                placeholder="correo@lastorres.cl"
                required
                className="w-full bg-muted border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent transition-colors"
              />
            </div>

            {/* Password */}
            <div>
              <label className="text-xs font-medium text-foreground mb-1.5 block">Contraseña</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(""); }}
                  placeholder="••••••••"
                  required
                  className="w-full bg-muted border border-border rounded-lg px-3 py-2.5 pr-10 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2.5">
                <AlertCircle size={13} className="shrink-0" />
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground py-2.5 rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-60 transition-colors mt-2"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                <LogIn size={15} />
              )}
              {loading ? "Verificando..." : "Ingresar"}
            </button>
          </form>
        </div>

        {/* Accesos rápidos demo */}
        <div className="mt-5 bg-card border border-border rounded-xl p-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 text-center">
            Accesos de demostración
          </p>
          <div className="space-y-2">
            {[
              { email: "admin@lastorres.cl",        label: "Administrador",  sub: "Ana Martínez",           color: "bg-primary/10 text-primary hover:bg-primary/20" },
              { email: "propietario@lastorres.cl",  label: "Propietario",    sub: "Patricia Herrera · 504", color: "bg-accent/10 text-accent hover:bg-accent/20" },
              { email: "arrendatario@lastorres.cl", label: "Arrendatario",   sub: "Roberto Cruz · 504",     color: "bg-emerald-50 text-emerald-700 hover:bg-emerald-100" },
            ].map(u => (
              <button
                key={u.email}
                onClick={() => quickLogin(u.email)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${u.color}`}
              >
                <div>
                  <p className="text-xs font-semibold">{u.label}</p>
                  <p className="text-xs opacity-70">{u.sub}</p>
                </div>
                <span className="text-xs opacity-60 font-mono">→ autocompletar</span>
              </button>
            ))}
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-5">
          © 2026 GestiónHogar · Edificio Las Torres
        </p>
      </div>
    </div>
  );
}
