import { TrendingUp, TrendingDown, Users, AlertCircle, CheckCircle2, DollarSign, Building, Clock } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const kpis = [
  { label: "Recaudación del Mes", value: "$4.820.500", change: "+8.3%", up: true, icon: DollarSign, color: "bg-green-50 text-green-700" },
  { label: "Deudas Pendientes", value: "$1.240.000", change: "+2.1%", up: false, icon: AlertCircle, color: "bg-red-50 text-red-600" },
  { label: "Total Residentes", value: "84", change: "0", up: true, icon: Users, color: "bg-blue-50 text-blue-700" },
  { label: "Pagos al Día", value: "91.7%", change: "+3.2%", up: true, icon: CheckCircle2, color: "bg-emerald-50 text-emerald-700" },
];

const monthlyData = [
  { mes: "Ene", recaudado: 4200000, esperado: 4800000 },
  { mes: "Feb", recaudado: 4500000, esperado: 4800000 },
  { mes: "Mar", recaudado: 4750000, esperado: 4800000 },
  { mes: "Abr", recaudado: 4100000, esperado: 4850000 },
  { mes: "May", recaudado: 4600000, esperado: 4850000 },
  { mes: "Jun", recaudado: 4820500, esperado: 4900000 },
];

const moraPorPiso = [
  { piso: "P1", mora: 0 },
  { piso: "P2", mora: 1 },
  { piso: "P3", mora: 2 },
  { piso: "P4", mora: 0 },
  { piso: "P5", mora: 3 },
  { piso: "P6", mora: 1 },
  { piso: "P7", mora: 0 },
];

const tipoResidente = [
  { name: "Propietarios", value: 52 },
  { name: "Arrendatarios", value: 32 },
];
const PIE_COLORS = ["#1B2E4B", "#2563EB"];

const alertas = [
  { tipo: "deuda", texto: "Apt. 305 — 3 meses de deuda acumulada ($360.000)", nivel: "alta" },
  { tipo: "deuda", texto: "Apt. 712 — 2 meses de deuda acumulada ($240.000)", nivel: "media" },
  { tipo: "pago", texto: "Apt. 201 — Pago recibido ayer ($120.000)", nivel: "ok" },
  { tipo: "pago", texto: "Apt. 504 — Pago recibido hoy ($120.000)", nivel: "ok" },
  { tipo: "alerta", texto: "Fondo de reserva al 68% — revisar aportaciones", nivel: "media" },
];

const fmtCLP = (v: number) => `$${(v / 1000000).toFixed(2)}M`;

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-xs">
      <p className="font-semibold mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }}>{p.name}: {fmtCLP(p.value)}</p>
      ))}
    </div>
  );
}

export function AdminDashboard() {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground">Panel de Control</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Edificio Las Torres — Junio 2026</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground bg-card border border-border rounded-lg px-3 py-2">
          <Clock size={13} />
          <span>Actualizado hace 2 min</span>
          <span className="w-2 h-2 rounded-full bg-green-500 ml-1"></span>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <div key={k.label} className="bg-card rounded-xl border border-border p-4">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${k.color}`}>
                  <Icon size={16} />
                </div>
                <span className={`flex items-center gap-0.5 text-xs font-medium ${k.up ? "text-green-600" : "text-red-500"}`}>
                  {k.up ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                  {k.change}
                </span>
              </div>
              <p className="text-xl font-semibold text-foreground">{k.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{k.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Area chart */}
        <div className="xl:col-span-2 bg-card rounded-xl border border-border p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-foreground">Recaudación vs Esperado</h3>
              <p className="text-xs text-muted-foreground">Últimos 6 meses</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={monthlyData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="gRec" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,46,75,0.06)" />
              <XAxis dataKey="mes" tick={{ fontSize: 11, fill: "#6B7A8F" }} axisLine={false} tickLine={false} />
              <YAxis tickFormatter={fmtCLP} tick={{ fontSize: 10, fill: "#6B7A8F" }} axisLine={false} tickLine={false} width={50} />
              <Tooltip content={<CustomTooltip />} />
              <Area key="esperado" type="monotone" dataKey="esperado" name="Esperado" stroke="#CBD5E1" strokeWidth={1.5} fill="none" strokeDasharray="4 4" />
              <Area key="recaudado" type="monotone" dataKey="recaudado" name="Recaudado" stroke="#2563EB" strokeWidth={2} fill="url(#gRec)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-foreground mb-1">Tipo de Residente</h3>
          <p className="text-xs text-muted-foreground mb-4">Distribución actual</p>
          <ResponsiveContainer width="100%" height={140}>
            <PieChart>
              <Pie data={tipoResidente} cx="50%" cy="50%" innerRadius={45} outerRadius={65} dataKey="value" paddingAngle={3}>
                {tipoResidente.map((t, i) => (
                  <Cell key={`pie-tipo-${t.name}`} fill={PIE_COLORS[i]} />
                ))}
              </Pie>
              <Tooltip formatter={(v: any) => [`${v} residentes`]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {tipoResidente.map((t, i) => (
              <div key={t.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm" style={{ background: PIE_COLORS[i] }}></span>
                  <span className="text-muted-foreground">{t.name}</span>
                </div>
                <span className="font-medium text-foreground">{t.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Mora por piso */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-foreground mb-1">Mora por Piso</h3>
          <p className="text-xs text-muted-foreground mb-4">Unidades con deuda activa</p>
          <ResponsiveContainer width="100%" height={150}>
            <BarChart data={moraPorPiso} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,46,75,0.06)" />
              <XAxis dataKey="piso" tick={{ fontSize: 11, fill: "#6B7A8F" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#6B7A8F" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip formatter={(v: any) => [`${v} unidad(es)`]} />
              <Bar dataKey="mora" name="Con mora" fill="#2563EB" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Alertas */}
        <div className="bg-card rounded-xl border border-border p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-foreground">Alertas Recientes</h3>
              <p className="text-xs text-muted-foreground">Actividad del sistema</p>
            </div>
            <span className="text-xs bg-red-50 text-red-600 px-2 py-0.5 rounded-full font-medium">2 urgentes</span>
          </div>
          <div className="space-y-2.5 overflow-y-auto max-h-[160px]">
            {alertas.map((a, i) => (
              <div key={i} className={`flex items-start gap-3 p-2.5 rounded-lg text-xs ${
                a.nivel === "alta" ? "bg-red-50" : a.nivel === "media" ? "bg-amber-50" : "bg-green-50"
              }`}>
                <span className={`mt-0.5 shrink-0 w-1.5 h-1.5 rounded-full ${
                  a.nivel === "alta" ? "bg-red-500" : a.nivel === "media" ? "bg-amber-500" : "bg-green-500"
                }`}></span>
                <span className={a.nivel === "alta" ? "text-red-700" : a.nivel === "media" ? "text-amber-700" : "text-green-700"}>
                  {a.texto}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
