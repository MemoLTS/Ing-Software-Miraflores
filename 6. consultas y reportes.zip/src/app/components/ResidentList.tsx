import { useState } from "react";
import { UserPlus, Mail, Phone, ChevronRight, CheckCircle2, XCircle, Clock } from "lucide-react";

const residentes = [
  { id: "R001", nombre: "Ana García Fuentes", apartamento: "101", piso: 1, tipo: "Propietario", estado: "Al día", email: "ana.garcia@email.com", tel: "+56 9 8765 4321", ingreso: "2021-03-01" },
  { id: "R002", nombre: "Carlos Muñoz Pinto", apartamento: "203", piso: 2, tipo: "Arrendatario", estado: "Con mora", email: "cmunoz@correo.cl", tel: "+56 9 7654 3210", ingreso: "2022-07-15" },
  { id: "R003", nombre: "Lucía Vera Soto", apartamento: "305", piso: 3, tipo: "Propietario", estado: "Deuda crítica", email: "lucia.vera@gmail.com", tel: "+56 9 6543 2109", ingreso: "2019-01-20" },
  { id: "R004", nombre: "Tomás Ríos Lagos", apartamento: "401", piso: 4, tipo: "Arrendatario", estado: "Al día", email: "trios@empresa.cl", tel: "+56 9 5432 1098", ingreso: "2023-05-01" },
  { id: "R005", nombre: "Valentina Bravo", apartamento: "502", piso: 5, tipo: "Propietario", estado: "Al día", email: "vbravo@email.com", tel: "+56 9 4321 0987", ingreso: "2020-09-10" },
  { id: "R006", nombre: "Roberto Cruz Valdivia", apartamento: "504", piso: 5, tipo: "Arrendatario", estado: "Con mora", email: "rcruz@mail.cl", tel: "+56 9 3210 9876", ingreso: "2024-01-05" },
  { id: "R007", nombre: "Fernanda López Cruz", apartamento: "601", piso: 6, tipo: "Propietario", estado: "Al día", email: "flopez@correo.cl", tel: "+56 9 2109 8765", ingreso: "2018-11-30" },
];

const estadoIcon = (e: string) => {
  if (e === "Al día") return <CheckCircle2 size={13} className="text-green-600" />;
  if (e === "Con mora") return <Clock size={13} className="text-amber-500" />;
  return <XCircle size={13} className="text-red-600" />;
};
const estadoColor = (e: string) => {
  if (e === "Al día") return "text-green-700 bg-green-50";
  if (e === "Con mora") return "text-amber-700 bg-amber-50";
  return "text-red-700 bg-red-50";
};

export function ResidentList() {
  const [selected, setSelected] = useState<string | null>(null);
  const sel = residentes.find(r => r.id === selected);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground">Residentes</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{residentes.length} residentes registrados</p>
        </div>
        <button className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm hover:bg-primary/90 transition-colors">
          <UserPlus size={14} /> Nuevo residente
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Lista */}
        <div className="xl:col-span-2 bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40">
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Residente</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Tipo</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Estado</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider"></th>
              </tr>
            </thead>
            <tbody>
              {residentes.map((r, i) => (
                <tr
                  key={r.id}
                  onClick={() => setSelected(r.id === selected ? null : r.id)}
                  className={`border-t border-border cursor-pointer transition-colors ${selected === r.id ? "bg-accent/5 border-l-2 border-l-accent" : i % 2 === 0 ? "hover:bg-muted/30" : "bg-muted/10 hover:bg-muted/30"}`}
                >
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
                        {r.nombre.split(" ").map(n => n[0]).slice(0, 2).join("")}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{r.nombre}</p>
                        <p className="text-xs text-muted-foreground">Apto. {r.apartamento} — Piso {r.piso}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${r.tipo === "Propietario" ? "bg-primary/10 text-primary" : "bg-accent/10 text-accent"}`}>
                      {r.tipo}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium w-fit ${estadoColor(r.estado)}`}>
                      {estadoIcon(r.estado)} {r.estado}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <ChevronRight size={14} className={`text-muted-foreground transition-transform ${selected === r.id ? "rotate-90" : ""}`} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Detalle */}
        <div className="bg-card border border-border rounded-xl p-5">
          {sel ? (
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                  {sel.nombre.split(" ").map(n => n[0]).slice(0, 2).join("")}
                </div>
                <div>
                  <h3 className="text-foreground">{sel.nombre}</h3>
                  <p className="text-xs text-muted-foreground">{sel.tipo} · Apto. {sel.apartamento}</p>
                </div>
              </div>
              <div className="space-y-3">
                {[
                  { label: "Estado", value: sel.estado, badge: true },
                  { label: "Piso", value: `Piso ${sel.piso}`, badge: false },
                  { label: "Ingreso", value: new Date(sel.ingreso).toLocaleDateString("es-CL"), badge: false },
                  { label: "Email", value: sel.email, badge: false },
                  { label: "Teléfono", value: sel.tel, badge: false },
                ].map(({ label, value, badge }) => (
                  <div key={label} className="flex items-start justify-between gap-2 text-sm">
                    <span className="text-muted-foreground shrink-0">{label}</span>
                    {badge ? (
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${estadoColor(value)}`}>{value}</span>
                    ) : (
                      <span className="text-foreground text-right">{value}</span>
                    )}
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-5 pt-4 border-t border-border">
                <button className="flex-1 flex items-center justify-center gap-1 text-xs bg-muted hover:bg-muted/70 text-foreground py-2 rounded-lg transition-colors">
                  <Mail size={12} /> Email
                </button>
                <button className="flex-1 flex items-center justify-center gap-1 text-xs bg-muted hover:bg-muted/70 text-foreground py-2 rounded-lg transition-colors">
                  <Phone size={12} /> Llamar
                </button>
                <button className="flex-1 flex items-center justify-center gap-1 text-xs bg-accent text-accent-foreground py-2 rounded-lg hover:bg-accent/90 transition-colors">
                  <ChevronRight size={12} /> Cuenta
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                <UserPlus size={20} className="text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-foreground">Selecciona un residente</p>
              <p className="text-xs text-muted-foreground mt-1">Haz clic en una fila para ver el detalle</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
