import { Building2, Phone, Mail, MapPin, Clock, FileText, AlertCircle, CheckCircle2, Megaphone } from "lucide-react";

const avisos = [
  { fecha: "2026-06-12", titulo: "Mantención ascensor — 16 de junio", cuerpo: "El ascensor principal estará fuera de servicio el lunes 16 de junio entre 09:00 y 13:00 hrs por mantención preventiva.", tipo: "info" },
  { fecha: "2026-06-10", titulo: "Recordatorio: pago gastos comunes vence el 1 de julio", cuerpo: "Se recuerda a todos los residentes que el plazo para el pago de gastos comunes del mes de julio vence el 1 de julio de 2026.", tipo: "alerta" },
  { fecha: "2026-06-05", titulo: "Nueva norma de ruido en áreas comunes", cuerpo: "A partir del 1 de julio, queda prohibido el uso de parlantes en la piscina. Se aplicarán multas de $50.000 por infracción.", tipo: "norma" },
  { fecha: "2026-05-28", titulo: "Asamblea de copropietarios — 25 de junio", cuerpo: "Se convoca a asamblea ordinaria el miércoles 25 de junio a las 19:30 hrs en el salón de eventos. Orden del día: presupuesto 2027 y reparación cubierta.", tipo: "info" },
];

const reglamento = [
  "El horario de silencio es de 22:00 a 08:00 hrs los días hábiles, y de 23:00 a 09:00 hrs los fines de semana y festivos.",
  "Las mascotas deben circular con correa en todas las áreas comunes del edificio.",
  "El uso de la piscina está permitido entre 09:00 y 20:00 hrs. Prohibido el ingreso fuera de ese horario.",
  "Los traslados de muebles y mudanzas se deben coordinar con la administración con al menos 48 horas de anticipación.",
  "La basura debe depositarse en los contenedores del subterráneo, clasificada según tipo (orgánico, reciclable, general).",
  "El estacionamiento de visitas tiene un límite de 4 horas. Las infracciones serán comunicadas al propietario.",
];

const administracion = {
  nombre: "Ana Martínez Rojas",
  cargo: "Administradora",
  empresa: "Gestión Inmobiliaria Sur Ltda.",
  telefono: "+56 2 2345 6789",
  celular: "+56 9 8765 4321",
  email: "administracion@lasторres.cl",
  horario: "Lunes a viernes, 09:00 – 17:00 hrs",
  urgencias: "+56 9 9999 0000",
};

const tipoIcon = (t: string) => {
  if (t === "alerta") return <AlertCircle size={14} className="text-amber-500 shrink-0 mt-0.5" />;
  if (t === "norma") return <FileText size={14} className="text-accent shrink-0 mt-0.5" />;
  return <Megaphone size={14} className="text-primary shrink-0 mt-0.5" />;
};
const tipoBg = (t: string) => {
  if (t === "alerta") return "border-amber-200 bg-amber-50/50";
  if (t === "norma") return "border-accent/20 bg-blue-50/30";
  return "border-border bg-card";
};

const fmtDate = (s: string) => new Date(s).toLocaleDateString("es-CL", { day: "2-digit", month: "long" });

interface Props {
  role: "propietario" | "arrendatario";
}

export function EdificioInfo({ role }: Props) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div>
        <h1 className="text-foreground">Información del Edificio</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Avisos, reglamento y contacto administrativo · RF-17</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Columna principal */}
        <div className="xl:col-span-2 space-y-5">
          {/* Avisos */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between">
              <h3 className="text-foreground">Avisos y Comunicados</h3>
              <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full font-medium">{avisos.length} avisos</span>
            </div>
            <div className="divide-y divide-border">
              {avisos.map((a, i) => (
                <div key={i} className={`p-4 flex gap-3 ${tipoBg(a.tipo)}`}>
                  {tipoIcon(a.tipo)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <p className="text-sm font-medium text-foreground">{a.titulo}</p>
                      <span className="text-xs text-muted-foreground shrink-0">{fmtDate(a.fecha)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{a.cuerpo}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Reglamento */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-foreground mb-4">Reglamento de Copropiedad</h3>
            <div className="space-y-3">
              {reglamento.map((r, i) => (
                <div key={i} className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-muted flex items-center justify-center text-xs font-semibold text-muted-foreground shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <p className="text-sm text-foreground leading-relaxed">{r}</p>
                </div>
              ))}
            </div>
            <button className="mt-4 text-xs text-accent hover:underline">
              Ver reglamento completo (PDF) →
            </button>
          </div>
        </div>

        {/* Columna derecha */}
        <div className="space-y-4">
          {/* Datos edificio */}
          <div className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Building2 size={18} className="text-primary" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Las Torres</p>
                <p className="text-xs text-muted-foreground">Edificio residencial</p>
              </div>
            </div>
            <div className="space-y-2.5 text-sm">
              <div className="flex items-start gap-2 text-muted-foreground">
                <MapPin size={13} className="shrink-0 mt-0.5" />
                <span>Av. Providencia 1234, Providencia, Santiago</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Building2 size={13} className="shrink-0" />
                <span>9 pisos · 84 unidades</span>
              </div>
            </div>
          </div>

          {/* Contacto administración */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-foreground mb-4">Administración</h3>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-full bg-accent/15 flex items-center justify-center text-sm font-semibold text-accent shrink-0">
                AM
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{administracion.nombre}</p>
                <p className="text-xs text-muted-foreground">{administracion.cargo}</p>
              </div>
            </div>
            <div className="space-y-2.5">
              {[
                { icon: Phone, label: administracion.telefono },
                { icon: Phone, label: administracion.celular },
                { icon: Mail,  label: administracion.email },
                { icon: Clock, label: administracion.horario },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-start gap-2 text-sm">
                  <Icon size={13} className="text-muted-foreground shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-1.5">Emergencias 24/7</p>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <p className="text-sm font-medium text-foreground">{administracion.urgencias}</p>
              </div>
            </div>
          </div>

          {/* Estado cuenta rápido */}
          {role === "arrendatario" && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle size={14} className="text-red-500" />
                <p className="text-sm font-medium text-red-700">Cuenta con saldo pendiente</p>
              </div>
              <p className="text-xs text-red-600">Revisa tu estado de cuenta para regularizar los pagos vencidos.</p>
            </div>
          )}
          {role === "propietario" && (
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <p className="text-sm font-medium text-green-700">Sus gastos comunes están al día</p>
              </div>
              <p className="text-xs text-green-600">Próximo vencimiento: 1 de julio de 2026.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
