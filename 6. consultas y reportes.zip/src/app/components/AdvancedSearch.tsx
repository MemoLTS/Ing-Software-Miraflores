import { useState } from "react";
import { Search, Filter, X, ChevronDown, Eye, Download } from "lucide-react";

type Residente = {
  id: string;
  nombre: string;
  apartamento: string;
  piso: number;
  tipo: "Propietario" | "Arrendatario";
  estado: "Al día" | "Con mora" | "Deuda crítica";
  deuda: number;
  meses: number;
};

const todos: Residente[] = [
  { id: "R001", nombre: "Ana García Fuentes", apartamento: "101", piso: 1, tipo: "Propietario", estado: "Al día", deuda: 0, meses: 0 },
  { id: "R002", nombre: "Carlos Muñoz Pinto", apartamento: "203", piso: 2, tipo: "Arrendatario", estado: "Con mora", deuda: 120000, meses: 1 },
  { id: "R003", nombre: "Lucía Vera Soto", apartamento: "305", piso: 3, tipo: "Propietario", estado: "Deuda crítica", deuda: 360000, meses: 3 },
  { id: "R004", nombre: "Tomás Ríos Lagos", apartamento: "401", piso: 4, tipo: "Arrendatario", estado: "Al día", deuda: 0, meses: 0 },
  { id: "R005", nombre: "Valentina Bravo", apartamento: "502", piso: 5, tipo: "Propietario", estado: "Al día", deuda: 0, meses: 0 },
  { id: "R006", nombre: "Roberto Cruz Valdivia", apartamento: "504", piso: 5, tipo: "Arrendatario", estado: "Con mora", deuda: 240000, meses: 2 },
  { id: "R007", nombre: "Fernanda López Cruz", apartamento: "601", piso: 6, tipo: "Propietario", estado: "Al día", deuda: 0, meses: 0 },
  { id: "R008", nombre: "Rodrigo Sánchez Vega", apartamento: "712", piso: 7, tipo: "Arrendatario", estado: "Con mora", deuda: 240000, meses: 2 },
  { id: "R009", nombre: "Camila Torres Núñez", apartamento: "803", piso: 8, tipo: "Propietario", estado: "Al día", deuda: 0, meses: 0 },
  { id: "R010", nombre: "Diego Morales Espinoza", apartamento: "901", piso: 9, tipo: "Arrendatario", estado: "Al día", deuda: 0, meses: 0 },
];

const fmtCLP = (n: number) => n === 0 ? "—" : new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(n);

export function AdvancedSearch() {
  const [query, setQuery] = useState("");
  const [tipo, setTipo] = useState<string>("todos");
  const [estado, setEstado] = useState<string>("todos");
  const [piso, setPiso] = useState<string>("todos");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = todos.filter(r => {
    const matchQ = query === "" || r.nombre.toLowerCase().includes(query.toLowerCase()) || r.apartamento.includes(query);
    const matchT = tipo === "todos" || r.tipo === tipo;
    const matchE = estado === "todos" || r.estado === estado;
    const matchP = piso === "todos" || r.piso === Number(piso);
    return matchQ && matchT && matchE && matchP;
  });

  const activeFilters = [tipo !== "todos" && tipo, estado !== "todos" && estado, piso !== "todos" && `Piso ${piso}`].filter(Boolean);

  const estadoColor = (e: string) => {
    if (e === "Al día") return "text-green-700 bg-green-50";
    if (e === "Con mora") return "text-amber-700 bg-amber-50";
    return "text-red-700 bg-red-50";
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div>
        <h1 className="text-foreground">Búsqueda y Filtros Avanzados</h1>
        <p className="text-sm text-muted-foreground mt-0.5">RF-17, RF-20 — Consulta en tiempo real con filtros configurables</p>
      </div>

      {/* Search bar */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Buscar por nombre o número de apartamento..."
            className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X size={13} />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(v => !v)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-all ${showFilters ? "bg-accent text-accent-foreground border-accent" : "bg-card border-border text-foreground hover:bg-muted"}`}
        >
          <Filter size={14} />
          Filtros
          {activeFilters.length > 0 && (
            <span className="w-5 h-5 text-xs bg-accent text-white rounded-full flex items-center justify-center">
              {activeFilters.length}
            </span>
          )}
        </button>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border bg-card text-sm text-foreground hover:bg-muted transition-colors">
          <Download size={14} /> Exportar
        </button>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium text-foreground">Filtros activos</p>
            {activeFilters.length > 0 && (
              <button onClick={() => { setTipo("todos"); setEstado("todos"); setPiso("todos"); }} className="text-xs text-accent hover:underline">
                Limpiar todos
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { label: "Tipo de residente", value: tipo, setter: setTipo, options: [["todos", "Todos"], ["Propietario", "Propietario"], ["Arrendatario", "Arrendatario"]] },
              { label: "Estado de cuenta", value: estado, setter: setEstado, options: [["todos", "Todos"], ["Al día", "Al día"], ["Con mora", "Con mora"], ["Deuda crítica", "Deuda crítica"]] },
              { label: "Piso", value: piso, setter: setPiso, options: [["todos", "Todos"], ["1", "Piso 1"], ["2", "Piso 2"], ["3", "Piso 3"], ["4", "Piso 4"], ["5", "Piso 5"], ["6", "Piso 6"], ["7", "Piso 7"], ["8", "Piso 8"], ["9", "Piso 9"]] },
            ].map(({ label, value, setter, options }) => (
              <div key={label}>
                <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
                <div className="relative">
                  <select
                    value={value}
                    onChange={e => setter(e.target.value)}
                    className="w-full appearance-none bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent pr-8"
                  >
                    {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </select>
                  <ChevronDown size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            ))}
          </div>
          {activeFilters.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-border">
              {activeFilters.map(f => (
                <span key={String(f)} className="flex items-center gap-1 text-xs bg-accent/10 text-accent px-2.5 py-1 rounded-full">
                  {f}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Results */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
          <p className="text-sm font-medium text-foreground">{filtered.length} resultado{filtered.length !== 1 ? "s" : ""}</p>
          <p className="text-xs text-muted-foreground">de {todos.length} residentes</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40">
                {["ID", "Residente", "Apartamento", "Tipo", "Estado", "Deuda", "Meses mora", ""].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-muted-foreground text-sm">
                    No se encontraron residentes con los filtros aplicados.
                  </td>
                </tr>
              ) : (
                filtered.map((r, i) => (
                  <tr key={r.id} className={`border-t border-border hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                    <td className="px-5 py-3.5"><span className="font-mono text-xs text-muted-foreground">{r.id}</span></td>
                    <td className="px-5 py-3.5 font-medium text-foreground">{r.nombre}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">Apto. {r.apartamento}</td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${r.tipo === "Propietario" ? "bg-primary/10 text-primary" : "bg-accent/10 text-accent"}`}>
                        {r.tipo}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${estadoColor(r.estado)}`}>{r.estado}</span>
                    </td>
                    <td className="px-5 py-3.5 font-medium text-foreground">{fmtCLP(r.deuda)}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{r.meses > 0 ? `${r.meses} mes${r.meses > 1 ? "es" : ""}` : "—"}</td>
                    <td className="px-5 py-3.5">
                      <button className="flex items-center gap-1 text-xs text-accent hover:underline">
                        <Eye size={12} /> Ver
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
