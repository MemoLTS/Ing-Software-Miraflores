import { useState } from "react";
import { Sidebar, type Role, type View } from "./components/Sidebar";
import { AdminDashboard } from "./components/AdminDashboard";
import { ResidentPortal } from "./components/ResidentPortal";
import { AdvancedSearch } from "./components/AdvancedSearch";
import { DynamicQuery } from "./components/DynamicQuery";
import { ResidentList } from "./components/ResidentList";
import { EdificioInfo } from "./components/EdificioInfo";
import { Login } from "./components/Login";
import { Settings, Building2, Bell, LogOut } from "lucide-react";

// ─── Settings placeholder ─────────────────────────────────────────────────────
function SettingsView() {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div>
        <h1 className="text-foreground">Configuración</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Administración del edificio y sistema</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {[
          { titulo: "Edificio", desc: "Nombre, dirección, pisos, unidades" },
          { titulo: "Gastos Comunes", desc: "Montos, criterios de distribución, vencimientos" },
          { titulo: "Notificaciones", desc: "Alertas automáticas, frecuencia, canales" },
          { titulo: "Usuarios y Roles", desc: "Accesos, permisos, perfiles de usuario" },
        ].map(({ titulo, desc }) => (
          <div key={titulo} className="bg-card border border-border rounded-xl p-5 flex items-start gap-4 hover:border-accent/30 transition-colors cursor-pointer group">
            <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center group-hover:bg-accent/10 transition-colors shrink-0">
              <Settings size={18} className="text-muted-foreground group-hover:text-accent transition-colors" />
            </div>
            <div>
              <h3 className="text-foreground">{titulo}</h3>
              <p className="text-sm text-muted-foreground mt-0.5">{desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Default views per role ───────────────────────────────────────────────────
const DEFAULT_VIEW: Record<Role, View> = {
  admin:        "dashboard",
  propietario:  "mi-cuenta",
  arrendatario: "mi-cuenta",
};

// ─── Render view ──────────────────────────────────────────────────────────────
function renderView(role: Role, view: View) {
  if (role === "admin") {
    switch (view) {
      case "dashboard":  return <AdminDashboard />;
      case "residents":  return <ResidentList />;
      case "search":     return <AdvancedSearch />;
      case "query":      return <DynamicQuery />;
      case "settings":   return <SettingsView />;
    }
  }

  if (role === "propietario") {
    switch (view) {
      case "mi-cuenta":       return <ResidentPortal viewAs="propietario" />;
      case "mi-arrendatario": return <ResidentPortal viewAs="arrendatario" readOnly />;
      case "edificio":        return <EdificioInfo role="propietario" />;
    }
  }

  if (role === "arrendatario") {
    switch (view) {
      case "mi-cuenta": return <ResidentPortal viewAs="arrendatario" />;
      case "edificio":  return <EdificioInfo role="arrendatario" />;
    }
  }

  return null;
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [role,       setRole]       = useState<Role>("admin");
  const [view,       setView]       = useState<View>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loggedIn,   setLoggedIn]   = useState(false);

  const handleLogin = (r: Role) => {
    setRole(r);
    setView(DEFAULT_VIEW[r]);
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setRole("admin");
    setView("dashboard");
  };

  const handleRoleChange = (r: Role) => {
    setRole(r);
    setView(DEFAULT_VIEW[r]);
  };

  if (!loggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* Desktop sidebar */}
      <div className="hidden md:flex">
        <Sidebar activeView={view} onViewChange={setView} role={role} onRoleChange={handleRoleChange} onLogout={handleLogout} />
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <div className="relative z-10">
            <Sidebar
              activeView={view}
              onViewChange={v => { setView(v); setMobileOpen(false); }}
              role={role}
              onRoleChange={handleRoleChange}
              onLogout={handleLogout}
            />
          </div>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile top bar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 bg-primary text-primary-foreground">
          <button
            onClick={() => setMobileOpen(true)}
            className="w-8 h-8 flex flex-col gap-1.5 items-center justify-center shrink-0"
          >
            <span className="w-5 h-0.5 bg-white rounded-full" />
            <span className="w-5 h-0.5 bg-white rounded-full" />
            <span className="w-5 h-0.5 bg-white rounded-full" />
          </button>
          <div className="flex items-center gap-2">
            <Building2 size={16} />
            <span className="text-sm font-semibold">GestiónHogar</span>
          </div>
          <div className="ml-auto">
            <Bell size={16} className="text-white/60" />
          </div>
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {renderView(role, view)}
        </div>
      </div>
    </div>
  );
}
